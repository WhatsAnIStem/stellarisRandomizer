##How this works:
##Edit the .ods file, since it's actually readable. Save it. Save it again as a .csv using the format below. The game reads the .csv file.
##
##
## When saving the weapon_components.ods file as .csv, the field delimiter option should be ;
## and the text delimiter option set to none/cleared
##
##
